public class WebHeladeria {
    public static void main(String [] args){
        VentanaInicio ventanaPrincipal = new VentanaInicio();
        ventanaPrincipal.setVisible(true);
    }
}